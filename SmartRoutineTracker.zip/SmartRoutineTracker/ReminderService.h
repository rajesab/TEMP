#pragma once
class ReminderService
{
public:
    void startService();
    void stopService();
    void viewScheduledNotifications();
    void addReminderCallback();
    void executeNotifications();
    void menu();
};

