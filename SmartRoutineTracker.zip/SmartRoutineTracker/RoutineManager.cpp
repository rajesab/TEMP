#include <iostream>
#include "RoutineManager.h"

using namespace std;

void RoutineManager::addRoutine()
{
    Routine r;
    json data = readFromFileJson();

    cout << "\nEnter ID : ";
    cin >> r.id;

    cin.ignore();

    cout << "Enter Title : ";
    getline(cin, r.title);

    cout << "Enter Category : ";
    getline(cin, r.category);

    cout << "Enter Priority : ";
    getline(cin, r.priority);

    string status = "Pending";

    for (auto s : data["routines"])
    {
        if (r.id == s["id"])
        {
            cout << "\nThis Routine is already Added.\n";
            return;
        }
    }
    data["routines"].push_back(
            {
                {"id", r.id},
                {"title", r.title},
                {"category", r.category},
                {"priority", r.priority},
                {"Status", status}
            });

    saveToFileJson(data);

    cout << "\nRoutine Added.\n";
    return;
}

void RoutineManager::viewRoutines()
{
    cout << "\n========== ROUTINES ==========\n";
    json data = readFromFileJson();
    if (data["routines"].empty())
    {
        cout << "No routines found.\n";
        return;
    }
    for (auto s : data["routines"])
    {
         utils::printRoutine(s);
    }
}

void RoutineManager::ViewPendingRoutines()
{
    utils::viewByStatus("Pending", "========== PENDING ROUTINES ==========");
}

void RoutineManager::ViewCompletedRoutines()
{
    utils::viewByStatus("Completed", "========== COMPLETED ROUTINES ==========");
}

void RoutineManager::markCompleted()
{
    int id;

    cout << "\nEnter Routine ID : ";
    cin >> id;
    json data = readFromFileJson();
    bool found = false;
    for (auto& s : data["routines"])
    {
        if(s["id"] == id)
        {
                s["Status"] = "Completed";
                found = true;
                break;
        }
    }
    if (found)
    {
        saveToFileJson(data);
        cout << "\nRoutine marked as Completed.\n";
    }
    else
    {
        cout << "\nRoutine ID not found.\n";
    }
}

void RoutineManager::UpdatePriority()
{
    int id;
    cout << "\nEnter Routine ID : ";
    cin >> id;
    json data = readFromFileJson();
    bool found = false;
    for (auto& s : data["routines"])
    {
        if(s["id"] == id)
        {
            string newPriority;
            cout<<" Enter the new priority: ";
            cin>>newPriority;
            s["priority"] = newPriority;
            found = true;
            break;
        }
    }
    if (found)
    {
        saveToFileJson(data);
        cout << "New Priority Updated Succesefully.\n";
    }
    else
    {
        cout << "\nRoutine ID not found.\n";
    }

}

void RoutineManager::CategorizeRoutine()
{
    string cat;
    bool found = false;
    cout<<"Enter the category which you want see: "<< cat <<endl;
    cin >> cat;
    json data = readFromFileJson();
    for (auto& s : data["routines"])
    {
        if(s["category"] == cat)
        {
            cout<<"These are belongs to category "<< cat <<endl;
            utils::printRoutine(s);
            found = true;
        }
    }
    if(!found)
    {
        cout << "Category Not Found.\n";
    }
    
}

void RoutineManager::deleteRoutine()
{
    int id;
    cout << "\nEnter Routine ID : ";
    cin >> id;
    json data = readFromFileJson();
    for(int i = 0; i < data["routines"].size(); i++)
    {
        if(data["routines"][i]["id"] == id)
        {
            data["routines"].erase(data["routines"].begin() + i);
            cout << "Routine Deleted.\n";
            saveToFileJson(data);
            return;
        }
    }
    cout << "Routine Not Found.\n";
}

void RoutineManager::SearchRoutine()
{
    int id;
    cout << "\nEnter Routine ID which you want to search : ";
    cin >> id;
    json data = readFromFileJson();
    for (auto& s : data["routines"])
    {
        if(s["id"] == id)
        {
            cout << "Routine Found details are.\n";
            utils::printRoutine(s);
            return;
        }
    }
    cout << "Routine Not Found.\n";
}

void RoutineManager::menu()
{
    int choice;

    do
    {
        cout << "\n=========================================\n";
        cout << "        ROUTINE MANAGEMENT\n";
        cout << "=========================================\n";

        cout << "1. Add Routine\n";
        cout << "2. View Routines\n";
        cout << "3. View Pending Routines\n";
        cout << "4. View Completed Routines\n";
        cout << "5. Mark Completed\n";
        cout << "6. Update Priority\n";
        cout << "7. Categorize Routine\n";
        cout << "8. Delete Routine\n";
        cout << "9. Search Routine\n";
        cout << "0. Back\n";

        cout << "\nEnter Choice : ";
        cin >> choice;

        switch(choice)
        {
            case 1:
                addRoutine();
                break;

            case 2:
                viewRoutines();
                break;

            case 3:
                ViewPendingRoutines();
                break;

            case 4:
                ViewCompletedRoutines();
                break;

            case 5:
                markCompleted();
                break;

            case 6:
                UpdatePriority();
                break;

            case 7:
                CategorizeRoutine();
                break;

            case 8:
                deleteRoutine();
                break;

            case 9:
                SearchRoutine();
                break;

            case 0:
                break;

            default:
                cout << "Invalid Choice.\n";
        }

    } while(choice != 0);
}
