#include <iostream>
#include "DataManager.h"

using namespace std;

void DataManager::saveData()
{
    cout << "\nData Saved Successfully.\n";
}

void DataManager::loadData()
{
    cout << "\nData Loaded Successfully.\n";
}

void DataManager::clearData()
{
    char choice;

    cout << "Do you want to delete all routines? (y/n): ";
    cin >> choice;

    if(choice == 'y' || choice == 'Y')
    {
        json data = readFromFileJson();
        data["routines"].clear();
        saveToFileJson(data);
        cout << "\nAll Data Cleared.\n";
    }
    else
    {
        cout << "\nOperation Cancelled.\n";
    }
}

void DataManager::menu()
{
    int choice;

    do
    {
        cout << "\n=========================================\n";
        cout << "          DATA MANAGEMENT\n";
        cout << "=========================================\n";

        cout << "1. Save Data\n";
        cout << "2. Load Data\n";
        cout << "3. Clear Data\n";
        cout << "0. Back\n";

        cout << "\nEnter Choice : ";
        cin >> choice;

        switch(choice)
        {
            case 1:
                saveData();
                break;

            case 2:
                loadData();
                break;

            case 3:
                clearData();
                break;

            case 0:
                break;

            default:
                cout << "Invalid Choice.\n";
        }

    } while(choice != 0);
}
