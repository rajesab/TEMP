#pragma once
#include "Routine.h"

class DataManager
{
public:
    void saveData();
    void loadData();
    void clearData();
    void menu();
};

