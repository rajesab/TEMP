#pragma once
#include <string>
#include <iostream>
#include <fstream>
#include <set>
#include "json.hpp"

using namespace std;
using json = nlohmann::ordered_json;

extern string filename;

void saveToFileJson(json data);
json readFromFileJson();

namespace utils
{
    // Common writer for one routine block in report files
    inline auto writeRoutineReportRow = [](ofstream& file, const auto& s)
        {
            file << "ID       : " << s["id"] << "\n";
            file << "Title    : " << s["title"] << "\n";
            file << "Priority : " << s["priority"] << "\n";
            file << "Category : " << s["category"] << "\n";
            file << "Status   : " << s["Status"] << "\n";
            file << "-----------------------------\n\n";
        };

    // Lambda to print a routine
    inline auto printRoutine = [](const auto& s)
        {
            cout << "\nID       : " << s["id"];
            cout << "\nTitle    : " << s["title"];
            cout << "\nPriority : " << s["priority"];
            cout << "\nCategory : " << s["category"];
            cout << "\nStatus   : " << s["Status"];
            cout << "\n-----------------------------\n";
        };

    // Lambda to view routines by status
    inline auto viewByStatus = [](const string& status, const string& header) {
            cout << "\n" << header << "\n";
            json data = readFromFileJson();
            bool found = false;
            for (auto s : data["routines"])
            {
                if(s["Status"] == status)
                {
                    utils::printRoutine(s);
                    found = true;
                }
            }
            if(!found)
            {
                cout << status << " Routines Not Found.\n";
            }
        };

    // Lambda to generate grouped reports (e.g., category-wise, priority-wise)
    inline auto generateGroupedReport = [](const json& data,
                                           const string& groupKey,
                                           const string& outputFile,
                                           const string& reportTitle,
                                           const string& groupLabel)
        {
            set<string> groups;
            for (const auto& s : data["routines"])
            {
                groups.insert(s[groupKey]);
            }

            ofstream file(outputFile);
            file << reportTitle << "\n\n";

            for (const auto& group : groups)
            {
                file << "These belong to " << groupLabel << " " << group << "\n\n";

                for (const auto& s : data["routines"])
                {
                    if (s[groupKey] == group)
                    {
                        utils::writeRoutineReportRow(file, s);
                    }
                }
            }

            file.close();
        };

    // Lambda to generate status-based reports (e.g., completed, pending)
    inline auto generateStatusReport = [](const json& data,
                                          const string& status,
                                          const string& outputFile,
                                          const string& reportTitle,
                                          const string& emptyMessage)
        {
            bool found = false;
            ofstream file(outputFile);
            file << reportTitle << "\n\n";

            for (const auto& s : data["routines"])
            {
                if (s["Status"] == status)
                {
                    utils::writeRoutineReportRow(file, s);
                    found = true;
                }
            }

            if (!found)
            {
                file << emptyMessage << "\n";
            }

            file.close();
        };
}
