#pragma once
#include "Routine.h"
#include <vector>
#include <set>

class ReportManager
{
public:
    std::vector<Routine> routines;

    void totalRoutines();
    void completedRoutines();
    void pendingRoutines();
    void completionPercentage();
    void categoryWiseReport();
    void priorityWiseReport();
    void menu();
};

