#pragma once
#include <string>
#include <iostream>
#include <fstream>
#include "Utils.h" 

using namespace std;

class Routine
{
public:
    int id;
    string title;
    string category;
    string priority;
    bool completed;

    Routine();
};

