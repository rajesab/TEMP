#include <iostream>
#include "ReportManager.h"

using namespace std;

void ReportManager::totalRoutines()
{
    json data = readFromFileJson();
    bool found = false;
    int totalRoutine = data["routines"].size();

    ofstream file("totalRoutines_report.csv");
    file << "The Total Routines Report\n\n";

    file << "Total Routines : "<< totalRoutine <<endl;

    for (auto s : data["routines"])
    {
        file << "ID       : " << s["id"] << "\n";
        file << "Title    : " << s["title"] << "\n";
        file << "Priority : " << s["priority"] << "\n";
        file << "Category : " << s["category"] << "\n";
        file << "Completed : " << s["Status"] << "\n";
        file << "-----------------------------\n\n";
        found = true;
    }
    if (!found)
    {
        file << "No routines found.\n";
    }

    file.close();
    cout << "Total Routines report generated successfully.\n";
}

void ReportManager::completedRoutines()
{
    json data = readFromFileJson();
    utils::generateStatusReport(data,
                                "Completed",
                                "completed_report.csv",
                                "The Routine Completed Report",
                                "Completed Routine Not Found.");

    cout << "Completed report generated successfully.\n";
}

void ReportManager::pendingRoutines()
{
    json data = readFromFileJson();
    utils::generateStatusReport(data,
                                "Pending",
                                "pending_report.csv",
                                "The Routine Pending Report",
                                "Pending Routine Not Found.");

    cout << "Pending report generated successfully.\n";
}

void ReportManager::completionPercentage()
{
    json data = readFromFileJson();
    int totalRoutine = data["routines"].size();
    ofstream file("completedPecentage_report.csv");
    file << "The Routin Completed percentage Report\n\n";

    int count = 0;
    for (auto s : data["routines"])
    {
        if(s["Status"] == "Completed")
        {
            count=count+1;
        }
    }
    float percentage =(static_cast<float>(count) / totalRoutine) * 100;
    file << "Percentage of Completed Routines : " << percentage <<"%" << "\n";
    file.close();

    cout << "Completion Percentage of Routines report generated successfully.\n";
}

void ReportManager::categoryWiseReport()
{
    json data = readFromFileJson();
    utils::generateGroupedReport(data,
                                 "category",
                                 "category_report.csv",
                                 "Category Wise Routines Report",
                                 "category");

    cout << "Category wise report generated successfully.\n";
}

void ReportManager::priorityWiseReport()
{
    json data = readFromFileJson();
    utils::generateGroupedReport(data,
                                 "priority",
                                 "priorities_report.csv",
                                 "priorities Wise Routines Report",
                                 "priority");

    cout << "priority wise report generated successfully.\n";
}

void ReportManager::menu()
{
    int choice;

    do
    {
        cout << "\n=========================================\n";
        cout << "        STATISTICS & REPORTS\n";
        cout << "=========================================\n";

        cout << "1. Total Routines\n";
        cout << "2. Completed Routines\n";
        cout << "3. Pending Routines\n";
        cout << "4. Completion Percentage\n";
        cout << "5. Category-wise Report\n";
        cout << "6. Priority-wise Report\n";
        cout << "0. Back\n";

        cout << "\nEnter Choice : ";
        cin >> choice;

        switch(choice)
        {
            case 1:
                totalRoutines();
                break;

            case 2:
                completedRoutines();
                break;

            case 3:
                pendingRoutines();
                break;

            case 4:
                completionPercentage();
                break;

            case 5:
                categoryWiseReport();
                break;

            case 6:
                priorityWiseReport();
                break;

            case 0:
                break;

            default:
                cout << "Invalid Choice.\n";
        }

    } while(choice != 0);
}
