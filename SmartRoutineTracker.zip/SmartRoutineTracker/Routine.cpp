#include "Routine.h"

string filename = "routines.json";

Routine::Routine()
{
    completed = false;
}

void saveToFileJson(json data)
{
    ofstream file(filename);
    file << data.dump(4);
    file.close();
}

json readFromFileJson()
{
    ifstream file(filename);
    json data;

    if (file.is_open())
        file >> data;
    else
        data["routines"] = json::array();

    file.close();
    return data;
}

void generateCSV(const json& data, const string& filename)
{
    ofstream file(filename);

    // Header
    file << "ID,Title,Category,Priority,Status\n";

    for (const auto& s : data["routines"])
    {
        file
        << s["id"] << ","
        << s["title"] << ","
        << s["category"] << ","
        << s["priority"] << ","
        << s["Status"] << "\n";
    }

    file.close();
    cout << "CSV Report Generated: " << filename << endl;
}

