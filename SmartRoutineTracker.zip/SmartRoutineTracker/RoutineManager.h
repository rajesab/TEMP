#pragma once
#include <vector>
#include "Routine.h"

class RoutineManager
{
private:

public:
    void addRoutine();
    void viewRoutines();
    void ViewPendingRoutines();
    void ViewCompletedRoutines();
    void markCompleted();
    void UpdatePriority();
    void CategorizeRoutine();
    void deleteRoutine();
    void SearchRoutine();
    void menu();
};

