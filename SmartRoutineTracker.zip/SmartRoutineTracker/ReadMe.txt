README
1. Category and Priority values will in integer values may be 1 to N.

2. No separate implementation for save and load data, since data is directly saved to a JSON file when adding routines and loaded when generating reports.

3. All reports will be generated as .csv files.

4. Reminder Service is not yet implemented.

Command to build the project:
g++ -std=c++17 main.cpp Routine.cpp RoutineManager.cpp ReminderService.cpp ReportManager.cpp DataManager.cpp -o app

To run the executable:
.\app.exe

